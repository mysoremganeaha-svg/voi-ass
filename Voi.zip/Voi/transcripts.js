const express = require('express');
const { Transcript, Meeting } = require('../models');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Get transcript for a meeting
router.get('/:meetingId', authenticate, async (req, res) => {
  try {
    const transcript = await Transcript.findOne({ meetingId: req.params.meetingId });
    if (!transcript) return res.status(404).json({ error: 'Transcript not found' });
    res.json({ transcript });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Search within transcript
router.get('/:meetingId/search', authenticate, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.status(400).json({ error: 'Search query required' });

    const transcript = await Transcript.findOne({ meetingId: req.params.meetingId });
    if (!transcript) return res.status(404).json({ error: 'Transcript not found' });

    const results = transcript.segments.filter(seg =>
      seg.text?.toLowerCase().includes(q.toLowerCase())
    );
    res.json({ results, total: results.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get action items from transcript
router.get('/:meetingId/action-items', authenticate, async (req, res) => {
  try {
    const transcript = await Transcript.findOne({ meetingId: req.params.meetingId });
    if (!transcript) return res.status(404).json({ error: 'Transcript not found' });

    const actionItems = transcript.segments.filter(seg => seg.isActionItem);
    res.json({ actionItems });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
