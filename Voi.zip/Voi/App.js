// src/App.js
import React, { useState, useEffect, useRef, useCallback } from 'react';

// ══════════════════════════════════════════════════════════
// MOCK SOCKET.IO (replaces real socket.io-client for demo)
// ══════════════════════════════════════════════════════════
class MockSocket {
  constructor() {
    this.handlers = {};
    this.meetingId = null;
    this.demoInterval = null;
    this.segmentCount = 0;
    this.speakers = [
      { id: 'SPEAKER_1', name: 'Alice Chen', color: '#7C3AED' },
      { id: 'SPEAKER_2', name: 'Bob Martinez', color: '#0891B2' },
      { id: 'SPEAKER_3', name: 'You', color: '#059669' },
    ];
    this.demoLines = [
      { speaker: 0, text: "Good morning everyone, let's get started with the Q4 planning session." },
      { speaker: 1, text: "Thanks Alice. I've reviewed the metrics and we're currently at 73% of our target." },
      { speaker: 2, text: "That's great progress. What are the main blockers we need to address?" },
      { speaker: 0, text: "The API integration is the critical path. Bob, can you take ownership of that?" },
      { speaker: 1, text: "Absolutely, I'll have an update ready by Friday. Action item for me." },
      { speaker: 2, text: "Perfect. We also need to decide on the design system before the sprint starts." },
      { speaker: 0, text: "Agreed. Let's go with Tailwind - that's our final decision on the stack." },
      { speaker: 1, text: "Makes sense. I'll update the documentation to reflect that decision." },
      { speaker: 2, text: "Should we also schedule a follow-up call with the design team next week?" },
      { speaker: 0, text: "Yes, let's do Thursday at 2pm. I'll send the calendar invite to everyone." },
      { speaker: 1, text: "One more thing - we need to finalize the budget proposal by end of month." },
      { speaker: 2, text: "I can draft that by Wednesday. Who should I loop in for approvals?" },
      { speaker: 0, text: "Loop in Finance and Legal. This needs sign-off from both departments." },
    ];
    this.lineIndex = 0;
  }

  on(event, handler) {
    if (!this.handlers[event]) this.handlers[event] = [];
    this.handlers[event].push(handler);
    return this;
  }

  emit(event, data) {
    if (event === 'join_meeting') {
      this.meetingId = data.meetingId;
      setTimeout(() => this._trigger('participant_joined', {
        userId: 'demo-user',
        name: 'You',
        participants: this.speakers.map(s => ({ name: s.name, socketId: s.id }))
      }), 300);
    }
    if (event === 'voice_command') {
      this._handleCommand(data.command);
    }
    if (event === 'request_summary') {
      this._generateSummary();
    }
    if (event === 'manual_transcript') {
      const seg = this._makeSegment(2, data.text, true);
      setTimeout(() => this._trigger('new_segment', { segment: seg }), 200);
    }
  }

  startDemoStream() {
    if (this.demoInterval) return;
    this.demoInterval = setInterval(() => {
      if (this.lineIndex >= this.demoLines.length) {
        this.lineIndex = 0;
      }
      const line = this.demoLines[this.lineIndex++];
      const seg = this._makeSegment(line.speaker, line.text);
      this._trigger('new_segment', { segment: seg });
      if (seg.isActionItem) this._trigger('action_item_detected', { segment: seg });
    }, 3500);
  }

  stopDemoStream() {
    if (this.demoInterval) {
      clearInterval(this.demoInterval);
      this.demoInterval = null;
    }
  }

  _makeSegment(speakerIdx, text, manual = false) {
    const speaker = this.speakers[speakerIdx];
    const actionKeywords = /\b(action item|will|need to|by friday|by wednesday|by thursday|task|follow up|send|update|loop in|schedule|finalize|draft)\b/i;
    const decisionKeywords = /\b(decided|agreed|final decision|let's go with|go with)\b/i;
    return {
      id: `seg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      speakerId: speaker.id,
      speakerName: speaker.name,
      speakerColor: speaker.color,
      text,
      startTime: this.segmentCount * 4,
      endTime: this.segmentCount * 4 + 3.5,
      confidence: 0.88 + Math.random() * 0.12,
      isActionItem: actionKeywords.test(text),
      isDecision: decisionKeywords.test(text),
      manual,
      createdAt: new Date()
    };
  }

  _handleCommand(command) {
    setTimeout(() => {
      this._trigger('command_processing', { command });
      setTimeout(() => {
        let response = '';
        const cmd = command.toLowerCase();
        if (cmd.includes('action item')) {
          response = '📋 **Action Items Found:**\n• Bob to complete API integration by Friday\n• Alice to send Thursday 2pm calendar invite\n• Draft budget proposal by Wednesday (loop in Finance & Legal)';
        } else if (cmd.includes('summar')) {
          response = '📊 **Meeting Summary (so far):**\nThe team discussed Q4 planning with current metrics at 73% of target. Key decisions include adopting Tailwind for the design system. Bob owns the API integration blocker. Budget proposal due end of month.';
        } else if (cmd.includes('decision')) {
          response = '✅ **Decisions Made:**\n• Tailwind selected as the design system\n• Thursday 2pm scheduled for design team follow-up\n• Finance & Legal required for budget sign-off';
        } else if (cmd.includes('who said')) {
          response = '🔍 Most recent speakers: Alice Chen (agenda), Bob Martinez (metrics update), You (questions). Alice spoke about API integration and ownership.';
        } else {
          response = '🤖 I can help you find information from this meeting. Try asking about "action items", "decisions", "summarize", or "who said [topic]".';
        }
        this._trigger('command_response', { command, response });
        this._trigger('assistant_message', { query: command, response, timestamp: Date.now() });
      }, 1500);
    }, 100);
  }

  _generateSummary() {
    setTimeout(() => {
      this._trigger('summary_update', {
        text: 'The Q4 planning session covered current performance metrics (73% of target), technical blockers, and key organizational decisions. The team established clear ownership and timelines for outstanding items.',
        keyPoints: [
          'Q4 metrics currently at 73% of target',
          'API integration identified as critical path blocker',
          'Tailwind selected as design system (final decision)',
          'Budget proposal deadline: end of month'
        ],
        actionItems: [
          { text: 'Complete API integration', assignee: 'Bob Martinez', priority: 'high' },
          { text: 'Send calendar invite for Thursday 2pm', assignee: 'Alice Chen', priority: 'medium' },
          { text: 'Draft budget proposal by Wednesday', assignee: 'You', priority: 'high' }
        ],
        decisions: [
          'Tailwind chosen as design system',
          'Thursday 2pm selected for design team follow-up',
          'Finance & Legal approval required for budget'
        ]
      });
    }, 1200);
  }

  _trigger(event, data) {
    (this.handlers[event] || []).forEach(h => h(data));
  }

  disconnect() {
    this.stopDemoStream();
    this.handlers = {};
  }
}

// ══════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ══════════════════════════════════════════════════════════
const formatTime = (seconds) => {
  if (!seconds && seconds !== 0) return '00:00';
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
};

const formatDuration = (ms) => {
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
};

const SPEAKER_COLORS = [
  '#7C3AED', '#0891B2', '#059669', '#D97706', '#DC2626',
  '#7C3AED', '#DB2777', '#2563EB', '#65A30D', '#EA580C'
];

const getSpeakerColor = (speakerId, speakers) => {
  const idx = Array.from(speakers.keys()).indexOf(speakerId);
  return SPEAKER_COLORS[idx % SPEAKER_COLORS.length];
};

// ══════════════════════════════════════════════════════════
// AUDIO VISUALIZER COMPONENT
// ══════════════════════════════════════════════════════════
function AudioVisualizer({ isRecording, isActive }) {
  const bars = 32;
  const [levels, setLevels] = React.useState(new Array(bars).fill(0.1));

  React.useEffect(() => {
    if (!isActive) {
      setLevels(new Array(bars).fill(0.05));
      return;
    }
    const interval = setInterval(() => {
      setLevels(prev => prev.map((_, i) => {
        const base = isRecording ? 0.3 : 0.05;
        const noise = isRecording ? Math.random() * 0.7 : Math.random() * 0.1;
        return base + noise;
      }));
    }, 80);
    return () => clearInterval(interval);
  }, [isActive, isRecording]);

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, height: 40, padding: '0 8px' }}>
      {levels.map((level, i) => (
        <div key={i} style={{
          width: 3, height: `${Math.max(4, level * 36)}px`,
          background: isRecording ? `rgba(124, 58, 237, ${0.4 + level * 0.6})` : 'rgba(156,163,175,0.4)',
          borderRadius: 2,
          transition: 'height 80ms ease, background 200ms ease'
        }} />
      ))}
    </div>
  );
}

// ══════════════════════════════════════════════════════════
// WAVEFORM ANIMATION
// ══════════════════════════════════════════════════════════
function PulseRing({ active }) {
  return (
    <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
      {active && [1, 2, 3].map(i => (
        <div key={i} style={{
          position: 'absolute',
          width: 48, height: 48,
          borderRadius: '50%',
          border: '2px solid rgba(124, 58, 237, 0.4)',
          animation: `pulse ${1.5 + i * 0.3}s ease-out infinite`,
          animationDelay: `${i * 0.3}s`
        }} />
      ))}
      <div style={{
        width: 48, height: 48, borderRadius: '50%',
        background: active ? '#7C3AED' : '#6B7280',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'background 0.3s ease', cursor: 'pointer',
        position: 'relative', zIndex: 1
      }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
          <path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3z"/>
          <path d="M19 10v1a7 7 0 0 1-14 0v-1M12 19v3M8 22h8"/>
        </svg>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════
// TRANSCRIPT SEGMENT COMPONENT
// ══════════════════════════════════════════════════════════
function TranscriptSegment({ segment, isNew }) {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setVisible(true), 50);
    return () => clearTimeout(t);
  }, []);

  const color = segment.speakerColor || '#7C3AED';
  const initials = (segment.speakerName || 'U').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);

  return (
    <div style={{
      display: 'flex', gap: 12, padding: '12px 0',
      borderBottom: '1px solid rgba(0,0,0,0.06)',
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(8px)',
      transition: 'opacity 0.3s ease, transform 0.3s ease'
    }}>
      <div style={{ flexShrink: 0 }}>
        <div style={{
          width: 32, height: 32, borderRadius: '50%',
          background: `${color}20`, border: `2px solid ${color}40`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, fontWeight: 600, color, fontFamily: 'monospace'
        }}>{initials}</div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color }}>{segment.speakerName}</span>
          <span style={{ fontSize: 11, color: '#9CA3AF' }}>{formatTime(segment.startTime)}</span>
          {segment.isActionItem && (
            <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: '#FEF3C7', color: '#92400E', fontWeight: 600 }}>
              ACTION
            </span>
          )}
          {segment.isDecision && (
            <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: '#D1FAE5', color: '#065F46', fontWeight: 600 }}>
              DECISION
            </span>
          )}
          {segment.voiceIdentified && (
            <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: '#EDE9FE', color: '#5B21B6', fontWeight: 600 }}>
              ✓ ID
            </span>
          )}
        </div>
        <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: '#1F2937' }}>{segment.text}</p>
        {segment.confidence < 0.8 && (
          <div style={{ marginTop: 4, fontSize: 11, color: '#9CA3AF' }}>
            Confidence: {Math.round(segment.confidence * 100)}%
          </div>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════
// MAIN APP COMPONENT
// ══════════════════════════════════════════════════════════
export default function App() {
  // State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [meetingStarted, setMeetingStarted] = useState(false);
  const [segments, setSegments] = useState([]);
  const [speakers, setSpeakers] = useState(new Map());
  const [participants, setParticipants] = useState([]);
  const [summary, setSummary] = useState(null);
  const [isSummaryLoading, setIsSummaryLoading] = useState(false);
  const [assistantMessages, setAssistantMessages] = useState([]);
  const [commandInput, setCommandInput] = useState('');
  const [isProcessingCommand, setIsProcessingCommand] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [activeTab, setActiveTab] = useState('transcript');
  const [elapsedTime, setElapsedTime] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [actionItems, setActionItems] = useState([]);
  const [meetingTitle, setMeetingTitle] = useState('Q4 Planning Session');
  const [showWelcome, setShowWelcome] = useState(true);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [audioStream, setAudioStream] = useState(null);

  // Refs
  const socketRef = useRef(null);
  const transcriptRef = useRef(null);
  const timerRef = useRef(null);
  const meetingIdRef = useRef('demo_' + Date.now());

  // Auto-scroll transcript
  const scrollToBottom = useCallback(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
    }
  }, []);

  useEffect(() => {
    if (segments.length > 0) scrollToBottom();
  }, [segments, scrollToBottom]);

  // Timer
  useEffect(() => {
    if (meetingStarted && !isPaused) {
      timerRef.current = setInterval(() => {
        setElapsedTime(t => t + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [meetingStarted, isPaused]);

  // Add notification
  const addNotification = useCallback((message, type = 'info') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 4000);
  }, []);

  // Setup WebSocket
  const setupSocket = useCallback(() => {
    if (socketRef.current) socketRef.current.disconnect();

    const socket = new MockSocket();
    socketRef.current = socket;

    socket.on('participant_joined', ({ participants: parts }) => {
      setParticipants(parts);
    });

    socket.on('new_segment', ({ segment }) => {
      setSegments(prev => [...prev, segment]);

      // Update speakers map
      setSpeakers(prev => {
        const next = new Map(prev);
        if (!next.has(segment.speakerId)) {
          next.set(segment.speakerId, {
            id: segment.speakerId,
            name: segment.speakerName,
            color: segment.speakerColor || SPEAKER_COLORS[next.size % SPEAKER_COLORS.length],
            segmentCount: 0
          });
        }
        const spk = next.get(segment.speakerId);
        spk.segmentCount = (spk.segmentCount || 0) + 1;
        return next;
      });
    });

    socket.on('action_item_detected', ({ segment }) => {
      setActionItems(prev => [...prev, segment]);
      addNotification(`Action item detected from ${segment.speakerName}`, 'warning');
    });

    socket.on('command_processing', () => setIsProcessingCommand(true));

    socket.on('command_response', ({ command, response }) => {
      setIsProcessingCommand(false);
      setAssistantMessages(prev => [...prev, {
        id: Date.now(),
        query: command,
        response,
        timestamp: new Date()
      }]);
    });

    socket.on('summary_update', (summaryData) => {
      setSummary(summaryData);
      setIsSummaryLoading(false);
    });

    socket.on('recording_paused', ({ by }) => addNotification(`Recording paused by ${by}`));
    socket.on('recording_resumed', ({ by }) => addNotification(`Recording resumed by ${by}`));

    return socket;
  }, [addNotification]);

  // Start meeting
  const startMeeting = useCallback(async () => {
    const socket = setupSocket();
    socket.emit('join_meeting', { meetingId: meetingIdRef.current });

    setMeetingStarted(true);
    setShowWelcome(false);
    setIsRecording(true);
    setElapsedTime(0);
    setSegments([]);
    setSpeakers(new Map());
    setActionItems([]);
    setSummary(null);
    setAssistantMessages([]);

    // Start demo stream
    socket.startDemoStream();

    // Try real microphone
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setAudioStream(stream);
      addNotification('Microphone connected', 'success');
    } catch (e) {
      addNotification('Demo mode: Using simulated audio', 'info');
    }
  }, [setupSocket, addNotification]);

  // Stop meeting
  const stopMeeting = useCallback(() => {
    setIsRecording(false);
    setMeetingStarted(false);
    setIsPaused(false);

    if (socketRef.current) {
      socketRef.current.stopDemoStream();
    }

    if (audioStream) {
      audioStream.getTracks().forEach(t => t.stop());
      setAudioStream(null);
    }

    addNotification('Meeting ended. Transcript saved.', 'success');

    // Generate final summary
    setIsSummaryLoading(true);
    setActiveTab('summary');
    if (socketRef.current) {
      socketRef.current.emit('request_summary', { meetingId: meetingIdRef.current });
    }
  }, [audioStream, addNotification]);

  // Pause/resume
  const togglePause = useCallback(() => {
    setIsPaused(prev => {
      const newPaused = !prev;
      if (socketRef.current) {
        if (newPaused) {
          socketRef.current.stopDemoStream();
        } else {
          socketRef.current.startDemoStream();
        }
      }
      return newPaused;
    });
  }, []);

  // Send command
  const sendCommand = useCallback(() => {
    if (!commandInput.trim() || isProcessingCommand) return;
    if (socketRef.current) {
      socketRef.current.emit('voice_command', {
        meetingId: meetingIdRef.current,
        command: commandInput.trim()
      });
    }
    setCommandInput('');
  }, [commandInput, isProcessingCommand]);

  // Send manual transcript
  const sendManual = useCallback(() => {
    if (!manualInput.trim()) return;
    if (socketRef.current) {
      socketRef.current.emit('manual_transcript', {
        meetingId: meetingIdRef.current,
        text: manualInput.trim()
      });
    }
    setManualInput('');
  }, [manualInput]);

  // Request summary
  const requestSummary = useCallback(() => {
    setIsSummaryLoading(true);
    if (socketRef.current) {
      socketRef.current.emit('request_summary', { meetingId: meetingIdRef.current });
    }
  }, []);

  // Export
  const exportNotes = useCallback(() => {
    const content = [
      `# ${meetingTitle}`,
      `Date: ${new Date().toLocaleDateString()}`,
      `Duration: ${formatDuration(elapsedTime * 1000)}`,
      '',
      '## Transcript',
      ...segments.map(s => `[${formatTime(s.startTime)}] **${s.speakerName}**: ${s.text}`),
      '',
      '## Action Items',
      ...actionItems.map(s => `- [${s.speakerName}]: ${s.text}`),
      '',
      summary ? [
        '## Summary',
        summary.text,
        '',
        '## Key Points',
        ...(summary.keyPoints || []).map(p => `- ${p}`),
        '',
        '## Decisions',
        ...(summary.decisions || []).map(d => `- ${d}`)
      ].join('\n') : ''
    ].join('\n');

    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `meeting-notes-${new Date().toISOString().split('T')[0]}.md`;
    a.click();
    URL.revokeObjectURL(url);
    addNotification('Notes exported successfully', 'success');
  }, [meetingTitle, segments, actionItems, summary, elapsedTime, addNotification]);

  const wordCount = segments.reduce((acc, s) => acc + (s.text?.split(' ').length || 0), 0);

  // CSS injection
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body { font-family: 'Inter', sans-serif; background: #0F0F13; color: #F9FAFB; min-height: 100vh; }
      @keyframes pulse { 0% { transform: scale(1); opacity: 0.8; } 100% { transform: scale(2.5); opacity: 0; } }
      @keyframes fadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
      @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      @keyframes breathe { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }
      .fade-in { animation: fadeIn 0.4s ease forwards; }
      .notification { animation: slideIn 0.3s ease forwards; }
      ::-webkit-scrollbar { width: 4px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
      input, textarea { outline: none; }
      input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.3); }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  // ──────────────────────────────────────────────────────────
  // WELCOME SCREEN
  // ──────────────────────────────────────────────────────────
  if (showWelcome) {
    return (
      <div style={{
        minHeight: '100vh', background: '#0F0F13', display: 'flex',
        alignItems: 'center', justifyContent: 'center', padding: 24,
        fontFamily: "'Inter', sans-serif"
      }}>
        {/* Animated background */}
        <div style={{ position: 'fixed', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
          {[...Array(6)].map((_, i) => (
            <div key={i} style={{
              position: 'absolute',
              width: 400 + i * 100, height: 400 + i * 100,
              borderRadius: '50%',
              border: `1px solid rgba(124, 58, 237, ${0.03 + i * 0.01})`,
              top: '50%', left: '50%',
              transform: 'translate(-50%, -50%)',
              animation: `breathe ${2 + i}s ease-in-out infinite`,
              animationDelay: `${i * 0.4}s`
            }} />
          ))}
        </div>

        <div style={{ maxWidth: 640, width: '100%', textAlign: 'center', position: 'relative' }}>
          {/* Logo */}
          <div style={{ marginBottom: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
            <div style={{
              width: 56, height: 56, borderRadius: 16,
              background: 'linear-gradient(135deg, #7C3AED, #4F46E5)',
              display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="1.5" />
                <path d="M8 12h8M8 8h5M8 16h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: 'white', letterSpacing: '-0.5px' }}>VoiceIQ</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.5px' }}>MEETING INTELLIGENCE</div>
            </div>
          </div>

          <h1 style={{ fontSize: 48, fontWeight: 700, color: 'white', letterSpacing: '-1.5px', lineHeight: 1.15, marginBottom: 16 }}>
            Your AI-powered<br/>
            <span style={{ background: 'linear-gradient(90deg, #7C3AED, #06B6D4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              meeting assistant
            </span>
          </h1>

          <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.5)', lineHeight: 1.7, marginBottom: 48 }}>
            Real-time transcription, speaker identification, and intelligent summaries — so you can focus on the conversation.
          </p>

          {/* Features grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 40 }}>
            {[
              { icon: '🎙', title: 'Speaker ID', desc: 'Voice biometrics identify each participant automatically' },
              { icon: '📝', title: 'Live Transcript', desc: 'Real-time speech-to-text with high accuracy' },
              { icon: '🤖', title: 'AI Assistant', desc: 'Ask questions, get summaries, extract action items' }
            ].map((f, i) => (
              <div key={i} style={{
                padding: '20px 16px', borderRadius: 12,
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                textAlign: 'left'
              }}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>{f.icon}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.9)', marginBottom: 4 }}>{f.title}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', lineHeight: 1.5 }}>{f.desc}</div>
              </div>
            ))}
          </div>

          {/* Meeting title input */}
          <div style={{ marginBottom: 16 }}>
            <input
              value={meetingTitle}
              onChange={e => setMeetingTitle(e.target.value)}
              placeholder="Meeting title..."
              style={{
                width: '100%', padding: '14px 18px', borderRadius: 12,
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.12)',
                color: 'white', fontSize: 15, fontFamily: 'inherit'
              }}
            />
          </div>

          <button
            onClick={startMeeting}
            style={{
              width: '100%', padding: '16px 24px', borderRadius: 12,
              background: 'linear-gradient(135deg, #7C3AED, #4F46E5)',
              border: 'none', color: 'white', fontSize: 16, fontWeight: 600,
              cursor: 'pointer', display: 'flex', alignItems: 'center',
              justifyContent: 'center', gap: 8, transition: 'transform 0.15s ease',
              fontFamily: 'inherit'
            }}
            onMouseEnter={e => e.target.style.transform = 'translateY(-2px)'}
            onMouseLeave={e => e.target.style.transform = 'translateY(0)'}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3z"/>
              <path d="M19 10v1a7 7 0 0 1-14 0v-1" stroke="white" strokeWidth="2" fill="none"/>
            </svg>
            Start Meeting
          </button>

          <p style={{ marginTop: 16, fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>
            Demo mode — simulated audio stream • Microphone optional
          </p>
        </div>
      </div>
    );
  }

  // ──────────────────────────────────────────────────────────
  // MAIN MEETING UI
  // ──────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', background: '#0F0F13', fontFamily: "'Inter', sans-serif", display: 'flex', flexDirection: 'column' }}>

      {/* ── NOTIFICATIONS ─────────────────────────── */}
      <div style={{ position: 'fixed', top: 16, right: 16, zIndex: 1000, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {notifications.map(n => (
          <div key={n.id} className="notification" style={{
            padding: '10px 16px', borderRadius: 8, fontSize: 13, fontWeight: 500,
            background: n.type === 'success' ? '#065F46' : n.type === 'warning' ? '#92400E' : '#1E3A5F',
            color: n.type === 'success' ? '#6EE7B7' : n.type === 'warning' ? '#FCD34D' : '#93C5FD',
            border: `1px solid ${n.type === 'success' ? '#10B981' : n.type === 'warning' ? '#F59E0B' : '#3B82F6'}33`,
            maxWidth: 280, boxShadow: '0 4px 12px rgba(0,0,0,0.4)'
          }}>{n.message}</div>
        ))}
      </div>

      {/* ── TOP HEADER ────────────────────────────── */}
      <header style={{
        height: 60, background: '#16161C', borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', padding: '0 20px', gap: 16,
        position: 'sticky', top: 0, zIndex: 100
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: 'linear-gradient(135deg, #7C3AED, #4F46E5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
              <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="2" fill="none"/>
              <path d="M8 12h8M8 8h5M8 16h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
            </svg>
          </div>
          <span style={{ fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.9)', letterSpacing: '-0.3px' }}>VoiceIQ</span>
        </div>

        <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.1)' }} />

        {/* Meeting title */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'white', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{meetingTitle}</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{formatDuration(elapsedTime * 1000)} • {segments.length} segments</div>
        </div>

        {/* Status indicator */}
        {isRecording && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 20, background: isPaused ? 'rgba(245,158,11,0.15)' : 'rgba(239,68,68,0.15)', border: `1px solid ${isPaused ? 'rgba(245,158,11,0.3)' : 'rgba(239,68,68,0.3)'}` }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: isPaused ? '#F59E0B' : '#EF4444', animation: isPaused ? 'none' : 'breathe 1.5s infinite' }} />
            <span style={{ fontSize: 11, fontWeight: 600, color: isPaused ? '#F59E0B' : '#EF4444', letterSpacing: '0.5px' }}>{isPaused ? 'PAUSED' : 'LIVE'}</span>
          </div>
        )}

        {/* Controls */}
        <div style={{ display: 'flex', gap: 8 }}>
          {isRecording && (
            <button onClick={togglePause} style={{
              padding: '6px 12px', borderRadius: 8,
              background: 'rgba(255,255,255,0.06)',
              border: '1px solid rgba(255,255,255,0.1)',
              color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: 500,
              cursor: 'pointer', fontFamily: 'inherit'
            }}>
              {isPaused ? '▶ Resume' : '⏸ Pause'}
            </button>
          )}
          <button onClick={exportNotes} style={{
            padding: '6px 12px', borderRadius: 8,
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: 500,
            cursor: 'pointer', fontFamily: 'inherit'
          }}>↓ Export</button>
          <button onClick={stopMeeting} style={{
            padding: '6px 12px', borderRadius: 8,
            background: 'rgba(239,68,68,0.15)',
            border: '1px solid rgba(239,68,68,0.3)',
            color: '#FCA5A5', fontSize: 12, fontWeight: 500,
            cursor: 'pointer', fontFamily: 'inherit'
          }}>■ End</button>
        </div>
      </header>

      {/* ── MAIN LAYOUT ───────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', height: 'calc(100vh - 60px)' }}>

        {/* LEFT SIDEBAR: Speakers */}
        <div style={{
          width: 220, background: '#16161C',
          borderRight: '1px solid rgba(255,255,255,0.06)',
          display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0
        }}>
          <div style={{ padding: '16px 16px 8px', fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px' }}>
            PARTICIPANTS
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '0 8px' }}>
            {Array.from(speakers.values()).map((speaker, i) => (
              <div key={speaker.id} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 8px', borderRadius: 8, marginBottom: 2,
                background: 'transparent'
              }}>
                <div style={{
                  width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
                  background: `${speaker.color}25`,
                  border: `2px solid ${speaker.color}60`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, color: speaker.color, fontFamily: 'monospace'
                }}>
                  {speaker.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'rgba(255,255,255,0.85)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{speaker.name}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{speaker.segmentCount} segments</div>
                </div>
              </div>
            ))}

            {speakers.size === 0 && (
              <div style={{ padding: '24px 8px', textAlign: 'center', color: 'rgba(255,255,255,0.25)', fontSize: 12 }}>
                Waiting for speakers...
              </div>
            )}
          </div>

          {/* Audio visualizer */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', padding: '12px 0' }}>
            <div style={{ textAlign: 'center', marginBottom: 8 }}>
              <PulseRing active={isRecording && !isPaused} />
            </div>
            <AudioVisualizer isRecording={isRecording && !isPaused} isActive={isRecording} />
            <div style={{ textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 4 }}>
              {isRecording && !isPaused ? 'Listening...' : isPaused ? 'Paused' : 'Stopped'}
            </div>
          </div>

          {/* Stats */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', padding: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[
                { label: 'Words', value: wordCount.toLocaleString() },
                { label: 'Actions', value: actionItems.length }
              ].map(stat => (
                <div key={stat.label} style={{ padding: '8px', borderRadius: 8, background: 'rgba(255,255,255,0.04)', textAlign: 'center' }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: 'white' }}>{stat.value}</div>
                  <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: '0.3px' }}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CENTER: Main content */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#111118' }}>

          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '0 20px', gap: 4, background: '#16161C' }}>
            {[
              { id: 'transcript', label: '📝 Transcript', count: segments.length },
              { id: 'summary', label: '📊 Summary' },
              { id: 'actions', label: '✅ Actions', count: actionItems.length },
              { id: 'assistant', label: '🤖 Assistant', count: assistantMessages.length }
            ].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
                padding: '12px 14px', border: 'none',
                background: 'transparent', cursor: 'pointer',
                fontSize: 13, fontWeight: activeTab === tab.id ? 600 : 400,
                color: activeTab === tab.id ? 'white' : 'rgba(255,255,255,0.4)',
                borderBottom: `2px solid ${activeTab === tab.id ? '#7C3AED' : 'transparent'}`,
                display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'inherit',
                transition: 'color 0.2s'
              }}>
                {tab.label}
                {tab.count > 0 && (
                  <span style={{ fontSize: 10, padding: '2px 5px', borderRadius: 10, background: activeTab === tab.id ? '#7C3AED' : 'rgba(255,255,255,0.1)', color: 'white' }}>
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>

            {/* TRANSCRIPT TAB */}
            {activeTab === 'transcript' && (
              <>
                <div ref={transcriptRef} style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
                  {segments.length === 0 && (
                    <div style={{ textAlign: 'center', padding: '60px 20px', color: 'rgba(255,255,255,0.2)' }}>
                      <div style={{ fontSize: 48, marginBottom: 12 }}>🎙</div>
                      <div style={{ fontSize: 15 }}>Transcript will appear here...</div>
                      <div style={{ fontSize: 12, marginTop: 8 }}>Speaking will be captured automatically</div>
                    </div>
                  )}
                  {segments.map((seg, i) => (
                    <div key={seg.id} style={{
                      padding: '10px 0',
                      borderBottom: '1px solid rgba(255,255,255,0.04)',
                      animation: 'fadeIn 0.3s ease'
                    }}>
                      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                        <div style={{
                          flexShrink: 0, width: 28, height: 28, borderRadius: '50%',
                          background: `${seg.speakerColor || '#7C3AED'}20`,
                          border: `1.5px solid ${seg.speakerColor || '#7C3AED'}60`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: 10, fontWeight: 700, color: seg.speakerColor || '#7C3AED',
                          fontFamily: 'monospace'
                        }}>
                          {(seg.speakerName || 'U').split(' ').map(w => w[0]).join('').slice(0, 2)}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3, flexWrap: 'wrap' }}>
                            <span style={{ fontSize: 12, fontWeight: 600, color: seg.speakerColor || '#7C3AED' }}>{seg.speakerName}</span>
                            <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)', fontFamily: 'monospace' }}>{formatTime(seg.startTime)}</span>
                            {seg.isActionItem && <span style={{ fontSize: 10, padding: '1px 6px', borderRadius: 4, background: 'rgba(251,191,36,0.15)', color: '#FCD34D', fontWeight: 600 }}>ACTION</span>}
                            {seg.isDecision && <span style={{ fontSize: 10, padding: '1px 6px', borderRadius: 4, background: 'rgba(52,211,153,0.15)', color: '#6EE7B7', fontWeight: 600 }}>DECISION</span>}
                          </div>
                          <p style={{ margin: 0, fontSize: 14, lineHeight: 1.65, color: 'rgba(255,255,255,0.85)' }}>{seg.text}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Manual input */}
                <div style={{ padding: 16, borderTop: '1px solid rgba(255,255,255,0.06)', background: '#16161C' }}>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input
                      value={manualInput}
                      onChange={e => setManualInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && sendManual()}
                      placeholder="Type to add transcript manually..."
                      style={{
                        flex: 1, padding: '10px 14px', borderRadius: 8,
                        background: 'rgba(255,255,255,0.06)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        color: 'white', fontSize: 13, fontFamily: 'inherit'
                      }}
                    />
                    <button onClick={sendManual} style={{
                      padding: '10px 16px', borderRadius: 8,
                      background: '#7C3AED', border: 'none',
                      color: 'white', fontSize: 13, fontWeight: 500,
                      cursor: 'pointer', fontFamily: 'inherit'
                    }}>Add</button>
                  </div>
                </div>
              </>
            )}

            {/* SUMMARY TAB */}
            {activeTab === 'summary' && (
              <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
                {!summary && !isSummaryLoading && (
                  <div style={{ textAlign: 'center', padding: '40px 0' }}>
                    <div style={{ fontSize: 48, marginBottom: 16 }}>📊</div>
                    <p style={{ color: 'rgba(255,255,255,0.4)', marginBottom: 20 }}>Generate a live summary of the meeting so far</p>
                    <button onClick={requestSummary} style={{
                      padding: '12px 24px', borderRadius: 10, background: '#7C3AED',
                      border: 'none', color: 'white', fontSize: 14, fontWeight: 600,
                      cursor: 'pointer', fontFamily: 'inherit'
                    }}>Generate Summary</button>
                  </div>
                )}

                {isSummaryLoading && (
                  <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <div style={{ width: 40, height: 40, border: '3px solid rgba(124,58,237,0.3)', borderTop: '3px solid #7C3AED', borderRadius: '50%', margin: '0 auto 16px', animation: 'spin 1s linear infinite' }} />
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Analyzing conversation...</div>
                  </div>
                )}

                {summary && (
                  <div style={{ animation: 'fadeIn 0.4s ease' }}>
                    {/* Executive summary */}
                    <div style={{ padding: 20, borderRadius: 12, background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.2)', marginBottom: 20 }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#A78BFA', letterSpacing: '0.8px', marginBottom: 10 }}>EXECUTIVE SUMMARY</div>
                      <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: 14, lineHeight: 1.7 }}>{summary.text}</p>
                    </div>

                    {/* Key Points */}
                    {summary.keyPoints?.length > 0 && (
                      <div style={{ marginBottom: 20 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px', marginBottom: 12 }}>KEY POINTS</div>
                        {summary.keyPoints.map((point, i) => (
                          <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                            <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(124,58,237,0.2)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: '#A78BFA', fontWeight: 700 }}>{i + 1}</div>
                            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, lineHeight: 1.5 }}>{point}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Items */}
                    {summary.actionItems?.length > 0 && (
                      <div style={{ marginBottom: 20 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px', marginBottom: 12 }}>ACTION ITEMS</div>
                        {summary.actionItems.map((item, i) => (
                          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 8, background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.15)', marginBottom: 6 }}>
                            <div style={{ width: 8, height: 8, borderRadius: '50%', background: item.priority === 'high' ? '#EF4444' : item.priority === 'medium' ? '#F59E0B' : '#6B7280', flexShrink: 0 }} />
                            <div style={{ flex: 1 }}>
                              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)' }}>{item.text}</div>
                              {item.assignee && <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>→ {item.assignee}</div>}
                            </div>
                            <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase' }}>{item.priority}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Decisions */}
                    {summary.decisions?.length > 0 && (
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px', marginBottom: 12 }}>DECISIONS MADE</div>
                        {summary.decisions.map((dec, i) => (
                          <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 12px', borderRadius: 8, background: 'rgba(52,211,153,0.06)', border: '1px solid rgba(52,211,153,0.15)', marginBottom: 6 }}>
                            <span style={{ color: '#34D399', fontSize: 14 }}>✓</span>
                            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, lineHeight: 1.5 }}>{dec}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    <button onClick={requestSummary} style={{
                      marginTop: 20, padding: '10px 20px', borderRadius: 8,
                      background: 'rgba(255,255,255,0.06)',
                      border: '1px solid rgba(255,255,255,0.1)',
                      color: 'rgba(255,255,255,0.6)', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit'
                    }}>↻ Refresh Summary</button>
                  </div>
                )}
              </div>
            )}

            {/* ACTION ITEMS TAB */}
            {activeTab === 'actions' && (
              <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
                {actionItems.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '60px 0', color: 'rgba(255,255,255,0.25)' }}>
                    <div style={{ fontSize: 40, marginBottom: 12 }}>✅</div>
                    <div>Action items will appear here automatically</div>
                  </div>
                ) : (
                  <>
                    <div style={{ marginBottom: 16, fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px' }}>
                      {actionItems.length} ACTION ITEMS DETECTED
                    </div>
                    {actionItems.map((item, i) => (
                      <div key={item.id} style={{
                        padding: '14px 16px', borderRadius: 10, marginBottom: 8,
                        background: 'rgba(255,255,255,0.04)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        animation: 'fadeIn 0.3s ease'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                          <span style={{ fontSize: 12, fontWeight: 600, color: item.speakerColor || '#A78BFA' }}>{item.speakerName}</span>
                          <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontFamily: 'monospace' }}>{formatTime(item.startTime)}</span>
                        </div>
                        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.8)', lineHeight: 1.5 }}>{item.text}</p>
                      </div>
                    ))}
                  </>
                )}
              </div>
            )}

            {/* ASSISTANT TAB */}
            {activeTab === 'assistant' && (
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
                  {/* Quick commands */}
                  <div style={{ marginBottom: 20 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.8px', marginBottom: 12 }}>QUICK COMMANDS</div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {['Summarize the meeting', 'List action items', 'What decisions were made?', 'Who spoke most?', 'Summarize last 5 minutes'].map(cmd => (
                        <button key={cmd} onClick={() => {
                          setCommandInput(cmd);
                          if (socketRef.current) {
                            socketRef.current.emit('voice_command', { meetingId: meetingIdRef.current, command: cmd });
                          }
                        }} style={{
                          padding: '6px 12px', borderRadius: 20,
                          background: 'rgba(124,58,237,0.1)',
                          border: '1px solid rgba(124,58,237,0.25)',
                          color: '#A78BFA', fontSize: 12, cursor: 'pointer', fontFamily: 'inherit'
                        }}>{cmd}</button>
                      ))}
                    </div>
                  </div>

                  {/* Message history */}
                  {assistantMessages.map(msg => (
                    <div key={msg.id} style={{ marginBottom: 20, animation: 'fadeIn 0.3s ease' }}>
                      <div style={{ padding: '10px 14px', borderRadius: '10px 10px 4px 10px', background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.2)', marginBottom: 8, display: 'inline-block', maxWidth: '80%', marginLeft: 'auto', display: 'block' }}>
                        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{msg.query}</div>
                      </div>
                      <div style={{ padding: '12px 16px', borderRadius: '4px 10px 10px 10px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
                        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{msg.response}</div>
                      </div>
                    </div>
                  ))}

                  {isProcessingCommand && (
                    <div style={{ display: 'flex', gap: 4, padding: '12px 16px' }}>
                      {[0, 1, 2].map(i => (
                        <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#7C3AED', animation: `breathe 1s infinite`, animationDelay: `${i * 0.2}s` }} />
                      ))}
                    </div>
                  )}
                </div>

                {/* Command input */}
                <div style={{ padding: 16, borderTop: '1px solid rgba(255,255,255,0.06)', background: '#16161C' }}>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input
                      value={commandInput}
                      onChange={e => setCommandInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && sendCommand()}
                      placeholder='Ask anything: "Who said that?" or "List action items"'
                      disabled={isProcessingCommand}
                      style={{
                        flex: 1, padding: '11px 14px', borderRadius: 10,
                        background: 'rgba(255,255,255,0.06)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        color: 'white', fontSize: 13, fontFamily: 'inherit'
                      }}
                    />
                    <button onClick={sendCommand} disabled={isProcessingCommand} style={{
                      padding: '11px 18px', borderRadius: 10,
                      background: isProcessingCommand ? 'rgba(124,58,237,0.3)' : '#7C3AED',
                      border: 'none', color: 'white', fontSize: 13, fontWeight: 600,
                      cursor: isProcessingCommand ? 'not-allowed' : 'pointer', fontFamily: 'inherit'
                    }}>Ask</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
