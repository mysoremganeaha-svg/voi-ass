// websocket/handler.js - Real-time WebSocket event handling
const jwt = require('jsonwebtoken');
const { Meeting, Transcript, User } = require('../models');
const { transcribeAudio, SpeakerDiarizer, identifySpeaker, extractVoiceEmbedding } = require('../services/speaker');
const { answerMeetingQuestion, classifySegment, extractKeywords, generateMeetingSummary } = require('../services/llm');

// Active meeting sessions: meetingId -> session data
const activeSessions = new Map();

class MeetingSession {
  constructor(meetingId) {
    this.meetingId = meetingId;
    this.diarizer = new SpeakerDiarizer();
    this.startTime = Date.now();
    this.segments = [];
    this.audioBuffer = Buffer.alloc(0);
    this.processingQueue = [];
    this.isProcessing = false;
    this.participants = new Map(); // socketId -> user info
    this.isPaused = false;
  }

  getElapsedSeconds() {
    return (Date.now() - this.startTime) / 1000;
  }
}

function setupWebSocket(io, logger) {
  // Auth middleware for socket connections
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token;
      if (!token) {
        // Allow unauthenticated connections for demo mode
        socket.user = { _id: 'demo', name: 'Demo User', email: 'demo@demo.com' };
        return next();
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
      const user = await User.findById(decoded.userId);
      if (!user) throw new Error('User not found');
      socket.user = user;
      next();
    } catch (err) {
      // Allow connection without auth for demo
      socket.user = { _id: 'demo', name: 'Demo User', email: 'demo@demo.com' };
      next();
    }
  });

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id} (${socket.user?.name})`);

    // ── Join meeting room ───────────────────────────────────────────────────
    socket.on('join_meeting', async ({ meetingId }) => {
      try {
        socket.join(meetingId);

        if (!activeSessions.has(meetingId)) {
          activeSessions.set(meetingId, new MeetingSession(meetingId));
        }

        const session = activeSessions.get(meetingId);
        session.participants.set(socket.id, {
          userId: socket.user._id,
          name: socket.user.name,
          socketId: socket.id,
          joinedAt: new Date()
        });

        // Notify room of new participant
        io.to(meetingId).emit('participant_joined', {
          userId: socket.user._id,
          name: socket.user.name,
          participants: Array.from(session.participants.values())
        });

        // Send existing transcript to newcomer
        socket.emit('transcript_sync', {
          segments: session.segments.slice(-50) // Last 50 segments
        });

        logger.info(`User ${socket.user.name} joined meeting ${meetingId}`);
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // ── Audio chunk received from client ────────────────────────────────────
    socket.on('audio_chunk', async ({ meetingId, audioData, timestamp }) => {
      try {
        const session = activeSessions.get(meetingId);
        if (!session || session.isPaused) return;

        // Queue audio for processing
        const audioBuffer = Buffer.from(audioData);
        session.processingQueue.push({ audioBuffer, timestamp, socketId: socket.id });

        // Process queue if not already processing
        if (!session.isProcessing) {
          processAudioQueue(session, meetingId, io, logger);
        }
      } catch (err) {
        logger.error('Audio chunk error:', err.message);
      }
    });

    // ── Voice command handler ────────────────────────────────────────────────
    socket.on('voice_command', async ({ meetingId, command }) => {
      try {
        const session = activeSessions.get(meetingId);
        if (!session) return;

        logger.info(`Voice command in ${meetingId}: "${command}"`);
        socket.emit('command_processing', { command });

        const cmd = command.toLowerCase();
        let response;

        // Parse voice commands
        const minutesMatch = cmd.match(/last\s+(\d+)\s+minute/);
        const minutes = minutesMatch ? parseInt(minutesMatch[1]) : null;

        if (cmd.includes('summarize') || cmd.includes('summary')) {
          response = await answerMeetingQuestion(
            minutes ? `Summarize the last ${minutes} minutes` : 'Summarize the meeting so far',
            session.segments,
            minutes
          );
        } else if (cmd.includes('action item')) {
          response = await answerMeetingQuestion('List all action items', session.segments);
        } else if (cmd.includes('decision')) {
          response = await answerMeetingQuestion('List all decisions made', session.segments);
        } else if (cmd.includes('who said')) {
          response = await answerMeetingQuestion(command, session.segments);
        } else if (cmd.includes('who is speaking') || cmd.includes('who spoke')) {
          const recent = session.segments.slice(-3);
          const speakers = [...new Set(recent.map(s => s.speakerName))];
          response = `Recently speaking: ${speakers.join(', ')}`;
        } else {
          response = await answerMeetingQuestion(command, session.segments);
        }

        socket.emit('command_response', { command, response, timestamp: Date.now() });

        // Broadcast response to room
        io.to(meetingId).emit('assistant_message', {
          query: command,
          response,
          timestamp: Date.now()
        });
      } catch (err) {
        socket.emit('command_error', { message: err.message });
      }
    });

    // ── Manual transcription input (text) ───────────────────────────────────
    socket.on('manual_transcript', async ({ meetingId, text, speakerId }) => {
      try {
        const session = activeSessions.get(meetingId);
        if (!session) return;

        const participant = session.participants.get(socket.id);
        const classification = await classifySegment(text);
        const keywords = extractKeywords(text);

        const segment = {
          id: `seg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          speakerId: speakerId || socket.id,
          speakerName: participant?.name || 'Unknown',
          speakerUserId: socket.user._id !== 'demo' ? socket.user._id : null,
          text,
          startTime: session.getElapsedSeconds(),
          endTime: session.getElapsedSeconds() + 2,
          confidence: 1.0,
          keywords,
          ...classification,
          createdAt: new Date()
        };

        session.segments.push(segment);
        await saveSegmentToDB(meetingId, segment, logger);

        io.to(meetingId).emit('new_segment', { segment });
      } catch (err) {
        logger.error('Manual transcript error:', err.message);
      }
    });

    // ── Request live summary ─────────────────────────────────────────────────
    socket.on('request_summary', async ({ meetingId, minutes }) => {
      try {
        const session = activeSessions.get(meetingId);
        if (!session) return;

        let segments = session.segments;
        if (minutes) {
          const cutoff = session.getElapsedSeconds() - (minutes * 60);
          segments = segments.filter(s => s.startTime >= cutoff);
        }

        if (segments.length === 0) {
          return socket.emit('summary_update', { text: 'Not enough transcript data yet.', keyPoints: [], actionItems: [], decisions: [] });
        }

        const summary = await generateMeetingSummary(segments, 'Current Meeting');
        socket.emit('summary_update', summary);
      } catch (err) {
        socket.emit('error', { message: 'Summary generation failed' });
      }
    });

    // ── Pause/resume recording ───────────────────────────────────────────────
    socket.on('pause_recording', ({ meetingId }) => {
      const session = activeSessions.get(meetingId);
      if (session) {
        session.isPaused = true;
        io.to(meetingId).emit('recording_paused', { by: socket.user.name });
      }
    });

    socket.on('resume_recording', ({ meetingId }) => {
      const session = activeSessions.get(meetingId);
      if (session) {
        session.isPaused = false;
        io.to(meetingId).emit('recording_resumed', { by: socket.user.name });
      }
    });

    // ── Speaker name update ──────────────────────────────────────────────────
    socket.on('update_speaker_name', ({ meetingId, speakerId, name }) => {
      const session = activeSessions.get(meetingId);
      if (session) {
        session.diarizer.updateSpeakerName(speakerId, name);
        // Update existing segments
        session.segments.forEach(seg => {
          if (seg.speakerId === speakerId) seg.speakerName = name;
        });
        io.to(meetingId).emit('speaker_renamed', { speakerId, name });
      }
    });

    // ── Disconnect ───────────────────────────────────────────────────────────
    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.id}`);
      
      // Remove from all sessions
      for (const [meetingId, session] of activeSessions) {
        if (session.participants.has(socket.id)) {
          session.participants.delete(socket.id);
          io.to(meetingId).emit('participant_left', {
            socketId: socket.id,
            participants: Array.from(session.participants.values())
          });

          // Clean up empty sessions after delay
          if (session.participants.size === 0) {
            setTimeout(() => {
              if (activeSessions.get(meetingId)?.participants.size === 0) {
                activeSessions.delete(meetingId);
                logger.info(`Session ${meetingId} cleaned up`);
              }
            }, 5 * 60 * 1000); // 5 minute grace period
          }
        }
      }
    });
  });

  // Periodic summary broadcast (every 5 minutes for active meetings)
  setInterval(async () => {
    for (const [meetingId, session] of activeSessions) {
      if (session.segments.length > 0 && session.participants.size > 0) {
        try {
          const recentSegments = session.segments.slice(-20);
          const summary = await generateMeetingSummary(recentSegments, 'Meeting Progress');
          io.to(meetingId).emit('auto_summary', { summary, timestamp: Date.now() });
        } catch (err) {
          // Silently fail periodic summaries
        }
      }
    }
  }, 5 * 60 * 1000);
}

// Process audio queue
async function processAudioQueue(session, meetingId, io, logger) {
  session.isProcessing = true;

  while (session.processingQueue.length > 0) {
    const { audioBuffer, timestamp, socketId } = session.processingQueue.shift();

    try {
      // Transcribe audio
      const transcription = await transcribeAudio(audioBuffer);
      if (!transcription.text || transcription.text.trim().length < 2) continue;

      // Extract voice embedding for speaker identification
      const embedding = await extractVoiceEmbedding(audioBuffer);
      const { speakerId, isNew } = session.diarizer.assignSpeaker(embedding, timestamp);
      
      const speakerData = session.diarizer.speakers.get(speakerId);
      
      // Try to identify known speaker
      const identified = await identifySpeaker(embedding, 0.80);
      let speakerName = speakerData?.name || `Speaker ${speakerId.split('_')[1]}`;
      
      if (identified.identified) {
        speakerName = identified.name;
        session.diarizer.updateSpeakerName(speakerId, speakerName);
      }

      // Classify segment
      const classification = await classifySegment(transcription.text);
      const keywords = extractKeywords(transcription.text);

      const segment = {
        id: `seg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        speakerId,
        speakerName,
        speakerUserId: identified.userId || null,
        text: transcription.text.trim(),
        startTime: session.getElapsedSeconds(),
        endTime: session.getElapsedSeconds() + 3,
        confidence: transcription.confidence,
        keywords,
        ...classification,
        voiceIdentified: identified.identified,
        createdAt: new Date()
      };

      session.segments.push(segment);

      // Save to DB
      await saveSegmentToDB(meetingId, segment, logger);

      // Broadcast to room
      io.to(meetingId).emit('new_segment', { segment });

      // Notify if new speaker detected
      if (isNew) {
        io.to(meetingId).emit('new_speaker_detected', {
          speakerId,
          speakerName,
          speakers: session.diarizer.getSpeakers()
        });
      }

      // Emit action item alert
      if (segment.isActionItem) {
        io.to(meetingId).emit('action_item_detected', { segment });
      }
    } catch (err) {
      logger.error(`Audio processing error: ${err.message}`);
    }
  }

  session.isProcessing = false;
}

// Save segment to database
async function saveSegmentToDB(meetingId, segment, logger) {
  try {
    if (meetingId.startsWith('demo_') || meetingId === 'demo') return;
    
    await Transcript.findOneAndUpdate(
      { meetingId },
      { 
        $push: { segments: segment },
        $set: { updatedAt: new Date() }
      },
      { upsert: true }
    );
  } catch (err) {
    logger.warn(`DB save failed for segment: ${err.message}`);
  }
}

module.exports = { setupWebSocket };
