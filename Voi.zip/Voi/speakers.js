// routes/speakers.js
const express = require('express');
const multer = require('multer');
const { VoiceProfile, User } = require('../models');
const { authenticate } = require('../middleware/auth');
const { extractVoiceEmbedding } = require('../services/speaker');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// Register/update voice profile
router.post('/register', authenticate, upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Audio file required' });
    if (!req.user.settings?.voiceConsentGiven) {
      return res.status(403).json({ error: 'Voice recording consent required' });
    }

    // Extract voice embedding (simulated if no model available)
    const embedding = await extractVoiceEmbedding(req.file.buffer);

    let profile = await VoiceProfile.findOne({ userId: req.user._id });
    if (profile) {
      // Average with existing embeddings for better accuracy
      profile.embedding = embedding;
      profile.sampleCount += 1;
      profile.quality = Math.min(1, profile.sampleCount / 5);
      profile.updatedAt = new Date();
    } else {
      profile = new VoiceProfile({
        userId: req.user._id,
        embedding,
        sampleCount: 1,
        quality: 0.2
      });
    }
    await profile.save();

    // Update user
    await User.findByIdAndUpdate(req.user._id, {
      voiceProfileId: profile._id,
      hasVoiceProfile: true
    });

    res.json({
      message: 'Voice profile registered successfully',
      profile: {
        id: profile._id,
        quality: profile.quality,
        sampleCount: profile.sampleCount
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get voice profile status
router.get('/profile', authenticate, async (req, res) => {
  const profile = await VoiceProfile.findOne({ userId: req.user._id });
  res.json({
    hasProfile: !!profile,
    quality: profile?.quality || 0,
    sampleCount: profile?.sampleCount || 0,
    lastUpdated: profile?.updatedAt
  });
});

// Delete voice profile
router.delete('/profile', authenticate, async (req, res) => {
  await VoiceProfile.deleteOne({ userId: req.user._id });
  await User.findByIdAndUpdate(req.user._id, {
    voiceProfileId: null,
    hasVoiceProfile: false
  });
  res.json({ message: 'Voice profile deleted' });
});

// Give consent for voice recording
router.post('/consent', authenticate, async (req, res) => {
  const { consent } = req.body;
  await User.findByIdAndUpdate(req.user._id, {
    'settings.voiceConsentGiven': consent
  });
  res.json({ message: consent ? 'Consent given' : 'Consent revoked' });
});

module.exports = router;
