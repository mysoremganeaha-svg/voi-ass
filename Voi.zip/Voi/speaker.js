// services/speaker.js - Speaker identification and diarization
const { VoiceProfile, User } = require('../models');

// Cosine similarity between two vectors
function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  const dot = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
  const magA = Math.sqrt(a.reduce((sum, ai) => sum + ai * ai, 0));
  const magB = Math.sqrt(b.reduce((sum, bi) => sum + bi * bi, 0));
  return magA && magB ? dot / (magA * magB) : 0;
}

// Extract voice embedding from audio buffer
// In production: integrate with Resemblyzer, SpeechBrain, or PyAnnote via microservice
async function extractVoiceEmbedding(audioBuffer) {
  // Simulate embedding extraction (256-dimensional vector)
  // Production: call Python microservice with Resemblyzer
  const embedding = new Array(256).fill(0).map(() => (Math.random() - 0.5) * 2);
  
  // Normalize the vector
  const magnitude = Math.sqrt(embedding.reduce((sum, x) => sum + x * x, 0));
  return embedding.map(x => x / magnitude);
}

// Identify speaker by matching voice embedding against registered profiles
async function identifySpeaker(embedding, threshold = 0.75) {
  try {
    const profiles = await VoiceProfile.find({}).populate('userId', 'name email');
    
    let bestMatch = null;
    let bestScore = 0;

    for (const profile of profiles) {
      if (!profile.embedding?.length) continue;
      const score = cosineSimilarity(embedding, profile.embedding);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = { profile, score };
      }
    }

    if (bestMatch && bestScore >= threshold) {
      return {
        identified: true,
        userId: bestMatch.profile.userId._id,
        name: bestMatch.profile.userId.name,
        confidence: bestScore
      };
    }

    return { identified: false, confidence: bestScore };
  } catch (err) {
    console.error('Speaker identification error:', err.message);
    return { identified: false, confidence: 0 };
  }
}

// Simple diarization state machine for tracking speakers
class SpeakerDiarizer {
  constructor() {
    this.speakers = new Map(); // speakerId -> { name, embedding, segmentCount }
    this.currentSpeaker = null;
    this.speakerCounter = 0;
    this.silenceThreshold = 500; // ms
    this.lastSegmentEnd = 0;
  }

  // Assign a speaker ID to a new audio segment
  assignSpeaker(embedding, timestamp) {
    // Find closest known speaker
    let bestMatch = null;
    let bestScore = 0;

    for (const [id, data] of this.speakers) {
      if (!data.embedding) continue;
      const score = cosineSimilarity(embedding, data.embedding);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = id;
      }
    }

    if (bestScore > 0.7 && bestMatch) {
      // Known speaker
      this.currentSpeaker = bestMatch;
      // Update embedding (moving average)
      const speaker = this.speakers.get(bestMatch);
      speaker.embedding = embedding.map((e, i) => (e + speaker.embedding[i]) / 2);
      speaker.segmentCount++;
      return { speakerId: bestMatch, isNew: false };
    } else {
      // New speaker
      const speakerId = `SPEAKER_${++this.speakerCounter}`;
      this.speakers.set(speakerId, {
        name: `Speaker ${this.speakerCounter}`,
        embedding,
        segmentCount: 1
      });
      this.currentSpeaker = speakerId;
      return { speakerId, isNew: true };
    }
  }

  updateSpeakerName(speakerId, name) {
    if (this.speakers.has(speakerId)) {
      this.speakers.get(speakerId).name = name;
    }
  }

  getSpeakers() {
    return Array.from(this.speakers.entries()).map(([id, data]) => ({
      id,
      name: data.name,
      segmentCount: data.segmentCount
    }));
  }

  reset() {
    this.speakers.clear();
    this.currentSpeaker = null;
    this.speakerCounter = 0;
  }
}

// Transcription service integration
async function transcribeAudio(audioBuffer, language = 'en') {
  // Production: Use OpenAI Whisper API or AssemblyAI
  const OpenAI = require('openai');
  
  if (!process.env.OPENAI_API_KEY) {
    // Mock transcription for demo
    return getMockTranscription();
  }

  try {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    
    // Convert buffer to file-like object
    const formData = new FormData();
    const blob = new Blob([audioBuffer], { type: 'audio/webm' });
    formData.append('file', blob, 'audio.webm');
    formData.append('model', 'whisper-1');
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'word');

    const response = await openai.audio.transcriptions.create({
      file: blob,
      model: 'whisper-1',
      language,
      response_format: 'verbose_json'
    });

    return {
      text: response.text,
      confidence: 0.95,
      words: response.words || []
    };
  } catch (err) {
    console.error('Transcription error:', err.message);
    return getMockTranscription();
  }
}

function getMockTranscription() {
  const samples = [
    "Let's get started with today's agenda.",
    "I think we should focus on the Q4 deliverables first.",
    "That makes sense. Can you give us an update on the current status?",
    "We're about 70% complete. The main blocker is the API integration.",
    "Okay, let's make that a priority action item for this week.",
    "Agreed. I'll take ownership of that and report back by Friday.",
    "Great. What about the design mockups? Are those ready?",
    "Yes, I shared them yesterday. We need feedback from the team by tomorrow.",
  ];
  return {
    text: samples[Math.floor(Math.random() * samples.length)],
    confidence: 0.85 + Math.random() * 0.15,
    words: []
  };
}

module.exports = { extractVoiceEmbedding, identifySpeaker, transcribeAudio, SpeakerDiarizer };
