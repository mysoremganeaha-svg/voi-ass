# VoiceIQ Meeting Assistant — API Documentation

**Base URL:** `http://localhost:3001`  
**Auth:** Bearer JWT token in `Authorization` header  
**Content-Type:** `application/json`

---

## Authentication

### POST /api/auth/register
Register a new user account.

**Request Body:**
```json
{
  "name": "Alice Chen",
  "email": "alice@company.com",
  "password": "securepassword123"
}
```

**Response (201):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "_id": "64f5e8a...",
    "name": "Alice Chen",
    "email": "alice@company.com",
    "hasVoiceProfile": false,
    "settings": { "language": "en", "voiceConsentGiven": false }
  }
}
```

---

### POST /api/auth/login
```json
{ "email": "alice@company.com", "password": "securepassword123" }
```

### GET /api/auth/me
Returns the current authenticated user.

### PUT /api/auth/profile
Update user profile settings.

---

## Meetings

### POST /api/meetings
Create a new meeting session.

**Request Body:**
```json
{
  "title": "Q4 Planning Session",
  "language": "en",
  "settings": {
    "transcriptionEnabled": true,
    "summaryEnabled": true,
    "autoIdentifySpeakers": true
  }
}
```

**Response (201):**
```json
{
  "meeting": {
    "_id": "64f5e8a...",
    "title": "Q4 Planning Session",
    "hostId": "64f5e7b...",
    "status": "scheduled",
    "participants": [...],
    "createdAt": "2025-01-15T09:00:00Z"
  },
  "transcriptId": "64f5e8b..."
}
```

---

### GET /api/meetings
List all meetings for the authenticated user.

**Query Parameters:**
- `status` — Filter by status: `scheduled|active|paused|ended`
- `limit` — Results per page (default: 20)
- `page` — Page number (default: 1)

---

### GET /api/meetings/:id
Get a specific meeting with full details.

---

### POST /api/meetings/:id/start
Start a scheduled meeting (host only).

---

### POST /api/meetings/:id/end
End an active meeting. Automatically generates final summary.

---

### GET /api/meetings/:id/summary
Get or generate the meeting summary.

**Response:**
```json
{
  "summary": {
    "text": "Executive summary of the meeting...",
    "keyPoints": ["Point 1", "Point 2"],
    "actionItems": [
      { "text": "Complete API integration", "assignee": "Bob", "priority": "high" }
    ],
    "decisions": ["Adopted Tailwind CSS for design system"],
    "generatedAt": "2025-01-15T10:30:00Z"
  }
}
```

---

### GET /api/meetings/:id/export
Export meeting notes as structured JSON.

---

## Transcripts

### GET /api/transcripts/:meetingId
Get the full transcript for a meeting.

**Response:**
```json
{
  "transcript": {
    "_id": "64f5e8b...",
    "meetingId": "64f5e8a...",
    "segments": [
      {
        "id": "seg_1705312800_abc123",
        "speakerId": "SPEAKER_1",
        "speakerName": "Alice Chen",
        "text": "Let's start with the agenda.",
        "startTime": 0,
        "endTime": 3.2,
        "confidence": 0.94,
        "isActionItem": false,
        "isDecision": false,
        "keywords": ["agenda", "start"],
        "createdAt": "2025-01-15T09:00:00Z"
      }
    ],
    "totalSegments": 47,
    "wordCount": 823
  }
}
```

---

### GET /api/transcripts/:meetingId/search?q=keyword
Search within a transcript.

### GET /api/transcripts/:meetingId/action-items
Get all action item segments from a transcript.

---

## Speaker / Voice Profiles

### POST /api/speakers/consent
Give or revoke consent for voice recording.
```json
{ "consent": true }
```

### POST /api/speakers/register
Register a voice profile. Requires `multipart/form-data` with an `audio` field (WAV/MP3/WebM, 5–30 seconds).

**Requirements:**
- `voiceConsentGiven` must be `true` for the user
- Audio: clear speech, 5–30 seconds, minimal background noise

**Response:**
```json
{
  "message": "Voice profile registered successfully",
  "profile": {
    "id": "64f5e8c...",
    "quality": 0.6,
    "sampleCount": 3
  }
}
```

### GET /api/speakers/profile
Get current user's voice profile status.

### DELETE /api/speakers/profile
Delete voice profile and all associated biometric data.

---

## WebSocket Events

Connect to `ws://localhost:3001` using Socket.IO.

**Authentication:**
```javascript
const socket = io('http://localhost:3001', {
  auth: { token: 'your-jwt-token' }
});
```

---

### Client → Server Events

| Event | Payload | Description |
|-------|---------|-------------|
| `join_meeting` | `{ meetingId }` | Join a meeting room |
| `audio_chunk` | `{ meetingId, audioData, timestamp }` | Send raw audio buffer for transcription |
| `manual_transcript` | `{ meetingId, text }` | Add manual transcript entry |
| `voice_command` | `{ meetingId, command }` | Send a voice command to the AI assistant |
| `request_summary` | `{ meetingId, minutes? }` | Request meeting summary |
| `pause_recording` | `{ meetingId }` | Pause recording |
| `resume_recording` | `{ meetingId }` | Resume recording |
| `update_speaker_name` | `{ meetingId, speakerId, name }` | Rename a detected speaker |

---

### Server → Client Events

| Event | Payload | Description |
|-------|---------|-------------|
| `participant_joined` | `{ userId, name, participants }` | Someone joined the meeting |
| `participant_left` | `{ socketId, participants }` | Someone left |
| `new_segment` | `{ segment }` | New transcript segment available |
| `new_speaker_detected` | `{ speakerId, speakerName, speakers }` | New speaker identified |
| `action_item_detected` | `{ segment }` | Action item detected in speech |
| `command_processing` | `{ command }` | Assistant is processing command |
| `command_response` | `{ command, response }` | Assistant response ready |
| `assistant_message` | `{ query, response, timestamp }` | Broadcast assistant response |
| `summary_update` | `{ text, keyPoints, actionItems, decisions }` | Summary generated |
| `auto_summary` | `{ summary, timestamp }` | Periodic auto-summary |
| `recording_paused` | `{ by }` | Recording paused notification |
| `recording_resumed` | `{ by }` | Recording resumed |

---

### Audio Chunk Format

Send audio in WebM/Opus format (browser MediaRecorder default):
```javascript
const recorder = new MediaRecorder(stream, {
  mimeType: 'audio/webm;codecs=opus'
});

recorder.ondataavailable = async (event) => {
  const buffer = await event.data.arrayBuffer();
  socket.emit('audio_chunk', {
    meetingId: 'meeting-id',
    audioData: buffer,
    timestamp: Date.now()
  });
};

recorder.start(3000); // Emit every 3 seconds
```

---

### Voice Command Examples

| Command | Action |
|---------|--------|
| "Summarize the meeting" | Full meeting summary |
| "Summarize last 5 minutes" | Last 5 min summary |
| "List action items" | All detected action items |
| "What decisions were made?" | Decision list |
| "Who said the API is blocked?" | Speaker attribution search |
| "Who is speaking?" | Recent speakers |

---

## Error Responses

All errors follow this format:
```json
{
  "error": "Description of what went wrong"
}
```

| Code | Meaning |
|------|---------|
| 400 | Bad Request — missing or invalid fields |
| 401 | Unauthorized — invalid or missing token |
| 403 | Forbidden — insufficient permissions |
| 404 | Not Found |
| 409 | Conflict — e.g., email already exists |
| 429 | Too Many Requests — rate limited |
| 500 | Internal Server Error |

---

## Rate Limits

- API endpoints: 100 requests / 15 minutes per IP
- WebSocket audio chunks: No hard limit (throttle client-side to max 1 chunk/3s)
- Summary generation: Internally throttled to prevent OpenAI API abuse

---

## Health Check

```
GET /health
```

```json
{
  "status": "ok",
  "timestamp": "2025-01-15T09:00:00Z",
  "version": "1.0.0",
  "services": {
    "database": "connected",
    "websocket": "active"
  }
}
```
