mkdir -p/home/claude/meeting-assistant/{frontend/src/
{components, hooks, services, store, types}, backend/{src/
{routes, services, middleware, models, websocket}, config}, docker, docs}
