// services/llm.js - LLM integration for meeting intelligence
const OpenAI = require('openai');

let openai;
try {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
} catch (e) {
  console.warn('OpenAI not configured - AI features will use mock responses');
}

// Generate meeting summary from transcript segments
async function generateMeetingSummary(segments, meetingTitle = 'Meeting') {
  const transcriptText = segments
    .map(s => `[${formatTime(s.startTime)}] ${s.speakerName || 'Speaker'}: ${s.text}`)
    .join('\n');

  if (!openai || !process.env.OPENAI_API_KEY) {
    return getMockSummary(segments, meetingTitle);
  }

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'system',
        content: `You are an expert meeting analyst. Analyze meeting transcripts and provide structured summaries. 
        Always respond with valid JSON in this exact format:
        {
          "text": "brief 2-3 sentence executive summary",
          "keyPoints": ["point 1", "point 2", ...],
          "actionItems": [{"text": "action item", "assignee": "name or null", "priority": "high|medium|low"}],
          "decisions": ["decision 1", "decision 2", ...]
        }`
      }, {
        role: 'user',
        content: `Analyze this meeting transcript for "${meetingTitle}":\n\n${transcriptText.substring(0, 8000)}`
      }],
      temperature: 0.3,
      max_tokens: 1000
    });

    const content = response.choices[0].message.content;
    return JSON.parse(content);
  } catch (err) {
    console.error('LLM summary error:', err.message);
    return getMockSummary(segments, meetingTitle);
  }
}

// Answer questions about the meeting
async function answerMeetingQuestion(question, segments, recentMinutes = null) {
  let relevantSegments = segments;

  if (recentMinutes) {
    const cutoffTime = segments.length > 0 
      ? segments[segments.length - 1].startTime - (recentMinutes * 60)
      : 0;
    relevantSegments = segments.filter(s => s.startTime >= cutoffTime);
  }

  const context = relevantSegments
    .map(s => `[${formatTime(s.startTime)}] ${s.speakerName || 'Speaker'}: ${s.text}`)
    .join('\n');

  if (!openai || !process.env.OPENAI_API_KEY) {
    return getMockAnswer(question, relevantSegments);
  }

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'system',
        content: `You are a helpful meeting assistant. Answer questions about the meeting transcript concisely and accurately. 
        If asked about "action items", list them clearly. If asked about "who said X", search the transcript carefully.
        If asked to summarize last N minutes, focus only on that time range. Keep responses concise (2-5 sentences unless listing items).`
      }, {
        role: 'user',
        content: `Meeting transcript:\n${context.substring(0, 6000)}\n\nQuestion: ${question}`
      }],
      temperature: 0.5,
      max_tokens: 500
    });

    return response.choices[0].message.content;
  } catch (err) {
    console.error('LLM Q&A error:', err.message);
    return getMockAnswer(question, relevantSegments);
  }
}

// Detect if a segment contains an action item or decision
async function classifySegment(text) {
  const actionPatterns = [
    /\b(will|should|need to|going to|action item|todo|task|follow up)\b/i,
    /\b(by|before|deadline|complete|finish|submit|send)\b/i
  ];
  const decisionPatterns = [
    /\b(decided|agreed|confirmed|approved|rejected|resolved|conclusion)\b/i,
    /\b(we will|let's go with|we'll use|final decision|settled on)\b/i
  ];

  return {
    isActionItem: actionPatterns.some(p => p.test(text)),
    isDecision: decisionPatterns.some(p => p.test(text))
  };
}

// Extract keywords from text
function extractKeywords(text) {
  const stopWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'this', 'that', 'these', 'those', 'i', 'we', 'you', 'he', 'she', 'it', 'they', 'so', 'if', 'not']);
  
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 3 && !stopWords.has(w))
    .slice(0, 5);
}

// Mock responses when OpenAI is not configured
function getMockSummary(segments, title) {
  const speakers = [...new Set(segments.map(s => s.speakerName).filter(Boolean))];
  const wordCount = segments.reduce((acc, s) => acc + (s.text?.split(' ').length || 0), 0);
  
  return {
    text: `This ${title} involved ${speakers.length} participant(s) with approximately ${wordCount} words discussed. The meeting covered various topics as captured in the transcript.`,
    keyPoints: [
      'Meeting transcription completed successfully',
      `${speakers.length} speaker(s) identified: ${speakers.join(', ') || 'Unknown'}`,
      `${segments.length} transcript segments captured`
    ],
    actionItems: [],
    decisions: []
  };
}

function getMockAnswer(question, segments) {
  const q = question.toLowerCase();
  
  if (q.includes('action item')) {
    const items = segments.filter(s => s.isActionItem);
    return items.length > 0
      ? `Action items found:\n${items.map(s => `• [${s.speakerName}]: ${s.text}`).join('\n')}`
      : 'No specific action items were detected in this portion of the meeting.';
  }
  
  if (q.includes('who said')) {
    const keyword = q.replace('who said', '').trim();
    const match = segments.find(s => s.text?.toLowerCase().includes(keyword));
    return match ? `${match.speakerName} mentioned that at ${formatTime(match.startTime)}.` : 'Could not find that quote in the transcript.';
  }
  
  if (q.includes('summar')) {
    const speakers = [...new Set(segments.map(s => s.speakerName).filter(Boolean))];
    return `In this portion: ${speakers.join(', ')} discussed ${segments.length} topics over ${formatTime(segments[segments.length - 1]?.startTime || 0)}.`;
  }
  
  return 'I can help you find information from the meeting transcript. Try asking about action items, decisions, or what a specific person said.';
}

function formatTime(seconds) {
  if (!seconds) return '00:00';
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

module.exports = { generateMeetingSummary, answerMeetingQuestion, classifySegment, extractKeywords };
