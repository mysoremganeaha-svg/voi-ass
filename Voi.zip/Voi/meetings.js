const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { Meeting, Transcript } = require('../models');
const { authenticate } = require('../middleware/auth');
const { generateMeetingSummary } = require('../services/llm');

const router = express.Router();

// Create meeting
router.post('/', authenticate, async (req, res) => {
  try {
    const { title, language = 'en', settings = {} } = req.body;
    const meeting = new Meeting({
      title: title || `Meeting - ${new Date().toLocaleDateString()}`,
      hostId: req.user._id,
      language,
      settings: {
        transcriptionEnabled: true,
        summaryEnabled: true,
        recordingEnabled: false,
        autoIdentifySpeakers: true,
        ...settings
      },
      participants: [{
        userId: req.user._id,
        name: req.user.name,
        email: req.user.email,
        joinedAt: new Date(),
        voiceIdentified: req.user.hasVoiceProfile
      }]
    });
    await meeting.save();

    // Create empty transcript
    const transcript = new Transcript({ meetingId: meeting._id, segments: [] });
    await transcript.save();

    res.status(201).json({ meeting, transcriptId: transcript._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all meetings for user
router.get('/', authenticate, async (req, res) => {
  try {
    const { status, limit = 20, page = 1 } = req.query;
    const query = {
      $or: [
        { hostId: req.user._id },
        { 'participants.userId': req.user._id }
      ]
    };
    if (status) query.status = status;

    const meetings = await Meeting.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit))
      .populate('hostId', 'name email avatar');

    const total = await Meeting.countDocuments(query);
    res.json({ meetings, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single meeting
router.get('/:id', authenticate, async (req, res) => {
  try {
    const meeting = await Meeting.findById(req.params.id)
      .populate('hostId', 'name email avatar')
      .populate('participants.userId', 'name email avatar hasVoiceProfile');
    if (!meeting) return res.status(404).json({ error: 'Meeting not found' });
    res.json({ meeting });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start meeting
router.post('/:id/start', authenticate, async (req, res) => {
  try {
    const meeting = await Meeting.findById(req.params.id);
    if (!meeting) return res.status(404).json({ error: 'Meeting not found' });
    if (meeting.hostId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Only host can start meeting' });
    }

    meeting.status = 'active';
    meeting.startTime = new Date();
    await meeting.save();
    res.json({ meeting });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// End meeting
router.post('/:id/end', authenticate, async (req, res) => {
  try {
    const meeting = await Meeting.findById(req.params.id);
    if (!meeting) return res.status(404).json({ error: 'Meeting not found' });

    meeting.status = 'ended';
    meeting.endTime = new Date();
    meeting.duration = meeting.startTime 
      ? Math.floor((meeting.endTime - meeting.startTime) / 1000) 
      : 0;

    // Generate final summary
    const transcript = await Transcript.findOne({ meetingId: meeting._id });
    if (transcript && transcript.segments.length > 0) {
      try {
        const summaryData = await generateMeetingSummary(transcript.segments, meeting.title);
        meeting.summary = { ...summaryData, generatedAt: new Date() };
      } catch (llmErr) {
        console.warn('Summary generation failed:', llmErr.message);
      }
    }

    await meeting.save();
    res.json({ meeting });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get meeting summary
router.get('/:id/summary', authenticate, async (req, res) => {
  try {
    const meeting = await Meeting.findById(req.params.id);
    if (!meeting) return res.status(404).json({ error: 'Meeting not found' });

    if (!meeting.summary?.text) {
      const transcript = await Transcript.findOne({ meetingId: meeting._id });
      if (transcript && transcript.segments.length > 0) {
        const summaryData = await generateMeetingSummary(transcript.segments, meeting.title);
        meeting.summary = { ...summaryData, generatedAt: new Date() };
        await meeting.save();
      }
    }

    res.json({ summary: meeting.summary });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Export meeting notes
router.get('/:id/export', authenticate, async (req, res) => {
  try {
    const meeting = await Meeting.findById(req.params.id)
      .populate('hostId', 'name email');
    const transcript = await Transcript.findOne({ meetingId: meeting._id });
    if (!meeting) return res.status(404).json({ error: 'Meeting not found' });

    const exportData = {
      meeting: {
        title: meeting.title,
        date: meeting.startTime,
        duration: meeting.duration,
        host: meeting.hostId?.name,
        participants: meeting.participants.map(p => ({ name: p.name, email: p.email }))
      },
      transcript: transcript?.segments?.map(seg => ({
        speaker: seg.speakerName,
        time: formatTime(seg.startTime),
        text: seg.text
      })) || [],
      summary: meeting.summary
    };

    res.json(exportData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function formatTime(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

module.exports = router;
