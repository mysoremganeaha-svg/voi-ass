// docker/mongo-init.js
// Initialize MongoDB with indexes and default data

db = db.getSiblingDB('meeting_assistant');

// Create indexes for performance
db.users.createIndex({ email: 1 }, { unique: true });
db.meetings.createIndex({ hostId: 1, createdAt: -1 });
db.meetings.createIndex({ 'participants.userId': 1 });
db.meetings.createIndex({ status: 1 });
db.transcripts.createIndex({ meetingId: 1 });
db.voiceprofiles.createIndex({ userId: 1 }, { unique: true });

print('✅ VoiceIQ MongoDB initialized with indexes');
